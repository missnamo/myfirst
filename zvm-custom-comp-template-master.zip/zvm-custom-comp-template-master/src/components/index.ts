import { Count } from './Count';

export default { Count };
